/*
 * functions.cpp
 *
 *  Created on: Feb 2, 2022
 *      Author: andre
 */

#include "functions.hpp"

void functions::decimalToBinary(int d) {
	int b = d;
	cout << "converting: " << d << "into binary" << endl;
	if (b >= 128) {
		b -= 128;
		bit8 = true;
	} else {
	} //bit8
	if (b >= 64) {
		b -= 64;
		bit7 = true;
	} else {
	} //bit7
	if (b >= 32) {
		b -= 32;
		bit6 = true;
	} else {
	} //bit6
	if (b >= 16) {
		b -= 16;
		bit5 = true;
	} else {
	} //bit5
	if (b >= 8) {
		b -= 8;
		bit4 = true;
	} else {
	} //bit4
	if (b >= 4) {
		b -= 4;
		bit3 = true;
	} else {
	} //bit3
	if (b >= 2) {
		b -= 2;
		bit2 = true;
	} else {
	} //bit2
	if (b >= 1) {
		b -= 1;
		bit1 = true;
	} else {
	} //bit1
	if (b > 0) {
		cout << "value over flowed the 8bit conversion!" << endl;
		cout << "result: " << bit8 << bit7 << bit6 << bit5 << bit4 << bit3
				<< bit2 << bit1 << endl;
	} else {
		cout << "result: " << bit8 << bit7 << bit6 << bit5 << bit4 << bit3
				<< bit2 << bit1 << endl;
	} //display check for over flow
	reset();
} //decimaltobinary
void functions::binaryToDecimal(string b) {
	int total = 0;
	int holder = b.size();
	for (unsigned int i = 0; i < b.size(); i++) {
		switch (i) {
		case 0:
			if (b[holder - 1] == '1') {
				total += 1;
			} else {

			} //bit 8
			break;
		case 1:
			if (b[holder - 2] == '1') {
				total += 2;
			} else {

			} //bit 7
			break;
		case 2:
			if (b[holder - 3] == '1') {
				total += 4;
			} else {

			} //bit 6
			break;
		case 3:
			if (b[holder - 4] == '1') {
				total += 8;
			} else {

			} //bit 5
			break;
		case 4:
			if (b[holder - 5] == '1') {
				total += 16;
			} else {

			} //bit 4
			break;
		case 5:
			if (b[holder - 6] == '1') {
				total += 32;
			} else {

			} //bit 3
			break;
		case 6:
			if (b[holder - 7] == '1') {
				total += 64;
			} else {

			} //bit 2
			break;
		case 7:
			if (b[holder - 8] == '1') {
				total += 128;
			} else {

			} //bit 1
			break;
		default:
			cout << "error loop went out of range" << endl;
		} //case statements for each array position.
	} //for
	cout << "The binary statement: " << b << " equals -> :" << total << endl;
} //binarytodecimal
void functions::decimalToHex(int d) {
	int temp = d;
	int remain = 0;
	int Aremain[4] = { 0, 0, 0, 0 };
	int pos = 0;
	char chex[4] = { '0', '0', '0', '0' };
	while (temp >= 1) {
		remain = temp % 16;
		Aremain[pos] = remain;
		temp = temp / 16;
		pos++;
	} //calculating the remainder and divisible length of the decimal
	for (int i = 0; i < 4; i++) {
		switch (Aremain[i]) {
		case 0:
			chex[i] = '0';
			break;
		case 1:
			chex[i] = '1';
			break;
		case 2:
			chex[i] = '2';
			break;
		case 3:
			chex[i] = '3';
			break;
		case 4:
			chex[i] = '4';
			break;
		case 5:
			chex[i] = '5';
			break;
		case 6:
			chex[i] = '6';
			break;
		case 7:
			chex[i] = '7';
			break;
		case 8:
			chex[i] = '8';
			break;
		case 9:
			chex[i] = '9';
			break;
		case 10:
			chex[i] = 'A';
			break;
		case 11:
			chex[i] = 'B';
			break;
		case 12:
			chex[i] = 'C';
			break;
		case 13:
			chex[i] = 'D';
			break;
		case 14:
			chex[i] = 'E';
			break;
		case 15:
			chex[i] = 'F';
			break;
		}
	} //for loop finding each base 16 value
	for (int i = 3; i > -1; i--) {
		cout << chex[i] << ", ";
	}
	cout << endl;
}
void functions::hexToDecimal(string h) {
	int total = 0;
	string trans = "0000";
	unsigned int p = 3;
	for (unsigned int i = 0; i < h.size(); i++) {
		trans[p] = h[i];
		p--;
	}
	for (int i = 0; i < 4; i++) { //TODO: Need to fix the orientation in wich the case statements read the string, they are currently reading it from back to front instead of front to back.
		switch (trans[i]) {
		case '0':
			total = total + base16(0, i);
			break;
		case '1':
			total = total + base16(1, i);
			break;
		case '2':
			total = total + base16(2, i);
			break;
		case '3':
			total = total + base16(3, i);
			break;
		case '4':
			total = total + base16(4, i);
			break;
		case '5':
			total = total + base16(5, i);
			break;
		case '6':
			total = total + base16(6, i);
			break;
		case '7':
			total = total + base16(7, i);
			break;
		case '8':
			total = total + base16(8, i);
			break;
		case '9':
			total = total + base16(9, i);
			break;
		case 'A':
		case 'a':
			total = total + base16(10, i);
			break;
		case 'B':
		case 'b':
			total = total + base16(11, i);
			break;
		case 'C':
		case 'c':
			total = total + base16(12, i);
			break;
		case 'D':
		case 'd':
			total = total + base16(13, i);
			break;
		case 'E':
		case 'e':
			total = total + base16(14, i);
			break;
		case 'F':
		case 'f':
			total = total + base16(15, i);
			break;
		}
	} //for loop finding each base 16 value
	cout << "The value of the hexadecimal in decimal is: " << total << endl;
}
void functions::reset(void) {
	bit8 = false;
	bit7 = false;
	bit6 = false;
	bit5 = false;
	bit4 = false;
	bit3 = false;
	bit2 = false;
	bit1 = false;
}
void functions::clearCIN() {
	cin.clear();
	cin.ignore(32768, '\n');
}
int functions::base16(int a, int p) {
	int base = 1;
	for (int i = 0; i < p; i++) {
		base *= 16;
	}
	return a = a * base;
}
