/*
 * functions.hpp
 *
 *  Created on: Feb 2, 2022
 *      Author: andre
 */

#ifndef FUNCTIONS_HPP_
#define FUNCTIONS_HPP_
#include <iostream>
using namespace std;

class functions {
public:
	void decimalToBinary(int d);
	void binaryToDecimal(string b);
	void decimalToHex(int d);
	void hexToDecimal(string h);
	void reset(void);
	void clearCIN(void);
	int base16(int a, int p);
private:
	bool bit8 = false;
	bool bit7 = false;
	bool bit6 = false;
	bool bit5 = false;
	bool bit4 = false;
	bool bit3 = false;
	bool bit2 = false;
	bool bit1 = false;

};

#endif /* FUNCTIONS_HPP_ */
