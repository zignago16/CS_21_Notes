//============================================================================
// Name        : CS21_ch1_project.cpp
// Author      : Andreas Zignago
// Version     : 1.00.00
// Copyright   : school_Project&Notes
// Description : CS21 ch1 project binary, decimal, hexdecimal converter , Ansi-style
//============================================================================

#include <iostream>
#include "functions.hpp"

/*TODO: Create a switch menu, containing 1,2,3,4, and 9 being exit **DONE**
 * 1: Decimal to Binary(decimalToBinary) **DONE**
 *     Decimals that are negative should display an error and request a valid entry
 * 2: Binary to Decimal(binaryToDecimal) **DONE**
 *     User can enter 1's and 0's for the binary input but only up to 8 bits
 *     If the input breaks any of those rules, display an error and request a valid entry
 * 3: Decimal to Hexadecimal(decimalToHex)**DONE**
 *     Decimals that are negative should display an error and request a valid entry
 * 4: Hexadecimal to Decimal(hexToDecimal)**DONE**
 *     the user is allowed to enter 0-9, and a,b,c,d,e,f
 *     the number of inputs allowed is up to 4,
 *      if it does not fit within either one of those rules display an error and request and valid entry.
 * 9: Exit **DONE**
 * TODO: Make sure the menu keeps running till 9 is entered to exit. **DONE**
 * TODO: Make sure the function names are exactly the same as from the project **DONE**
 *
 *
 */
int main() {
	functions funct;
	int a = 0;
	int dec = 0;
	string bin = "00000000";
	string hex = "0000";
	bool cleared = false;
	bool cstate = true;
	do {
		cout << "Numeric Converter " << endl;
		cout << "Menu: " << endl;
		cout << "1: Decimal to Binary" << endl << "2: Binary to Decimal" << endl
				<< "3: Decimal to Hexadecimal" << endl
				<< "4: Hexadecimal to Decimal" << endl << "9: Exit Program"
				<< endl << "->";
		cin >> a;
		funct.clearCIN();
		switch (a) {
		case 1:
			cout << " menu 1 " << endl << "Please enter a value -> ";
			cin >> dec;
			if (dec >= 0) {
				funct.decimalToBinary(dec);
			} else {
				cout << "value inputed was negative, returning to main menu. "
						<< endl;
			} //if function input check
			break;
		case 2:
			cout << " menu 2 " << endl << "please enter 8 binary digits ->";
			cin >> bin;
			funct.clearCIN();
			for (unsigned int i = 0; i < bin.size(); i++) {
				if ((bin[i] != '1' && bin[i] != '0') || bin.size() > 8) {
					cout
							<< "user entry is invalid, please only enter 1's or 0's up to 8 bits."
							<< endl << "Returning to menu." << endl;
					cleared = false;
					break;
				} else {
					cleared = true;
				} //checks the position and size
			} //loops through the size of the statement
			if (cleared) {
				funct.binaryToDecimal(bin);
			} else {
			}
			break;
		case 3:
			cout << " menu 3 " << endl << "Please enter a value -> ";
			cin >> dec;
			if (dec >= 0) {
				funct.decimalToHex(dec);
			} else {
				cout << "value inputed was negative, returning to main menu. "
						<< endl;
			} //if function input check
			break;
		case 4:
			cout << " menu 4 " << endl
					<< "Please enter a 4 digit hexadecimal -> ";
			cin >> hex;
			funct.clearCIN();
			for (unsigned int i = 0; i < hex.size(); i++) {
				if ((((hex[i] >= '0') && (hex[i] <= '9'))
						|| (((hex[i] >= 'a') && (hex[i] <= 'f'))
								|| ((hex[i] >= 'A') && (hex[i] <= 'F'))))
						&& hex.size() <= 4) {

					cleared = true;
				} else {
					cout << "User entry was not 0-9, A-F, or at most 4 digits."
							<< endl;
					cout << " Returning to menu" << endl;
					cleared = false;
					break;
				}
			} // the loop to check the value of the inputs
			if (cleared) {
				funct.hexToDecimal(hex);
			} else {

			}
			break;
		case 9:
			cout << "Now leaving the menu" << endl;
			cstate = false;
			break;
		default:
			cout
					<< "Please choose an option from the menu by entering 1-4 or 9 to exit "
					<< endl;
		} //switch menu
	} while (cstate); //menu loop

	cout << "Program Ending, Good Bye." << endl; // prints Program Ending, Good Bye.
	return 0;
}
